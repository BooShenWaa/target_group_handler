const Dynamo = require("./dynamo");
const {
  GetResourceID,
  RegisterNewTarget,
  DeregisterTarget,
} = require("./functions.js");

// Lambda Variables
let NLB_TARGET_GROUP_ARN = process.env.NLB_TARGET_GROUP_ARN;
let NLB_TARGET_PORT = process.env.NLB_TARGET_PORT;
let ALB_ARN = process.env.ALB_ARN;
let DYNAMO_TABLE = process.env.DYNAMO_TABLE;

// let NLB_TARGET_GROUP_ARN =
//   "arn:aws:elasticloadbalancing:eu-west-2:774752154143:targetgroup/NLB-TG/f18f02ff5e334b41";
// let NLB_TARGET_PORT = 80;
// let ALB_ARN =
//   "arn:aws:elasticloadbalancing:eu-west-2:774752154143:loadbalancer/app/ALB/61ec9a2327e95bd4";
// let DYNAMO_TABLE = "list";
// let REGION = "eu-west-2";

exports.handler = async (event) => {
  const input = event.detail;

  console.log("Determening event type...");

  if (input.eventName == "CreateNetworkInterface") {
    console.log("CreateNetworkInterface event detected...");
    // Pull required information from the event
    const eventDescription = input.requestParameters.description;
    const eventResourceID = eventDescription.split("/")[2];
    const ALB_RESOURCE_ID = GetResourceID(ALB_ARN);
    const createEventIp =
      input.responseElements.networkInterface.privateIpAddress;
    const eniID = input.responseElements.networkInterface.networkInterfaceId;

    // Confirm even matches the correct ALB
    if (ALB_RESOURCE_ID == eventResourceID) {
      console.log(
        "Attempting to register: ",
        createEventIp + " to " + NLB_TARGET_GROUP_ARN,
      );

      // Register IP to NLB TG
      await RegisterNewTarget(
        NLB_TARGET_GROUP_ARN,
        NLB_TARGET_PORT,
        createEventIp,
      );

      const newEntry = {
        ID: eniID,
        IP: createEventIp,
      };

      // Add entry to the DynamoDB table
      console.log("Writing to table...");
      await Dynamo.write(newEntry, DYNAMO_TABLE);
      return;
    } else {
      console.log(
        "Event does not match the Application Load Balancer selected",
      );
    }
  } else if (input.eventName == "DeleteNetworkInterface") {
    console.log("DeleteNetworkInterface event detected...");

    const eventEni = input.requestParameters.networkInterfaceId;

    try {
      await DeregisterTarget(NLB_TARGET_GROUP_ARN, NLB_TARGET_PORT, eventEni);

      console.log("Removing entry from table...");
      await Dynamo.delete(eventEni, DYNAMO_TABLE);
      return;
    } catch (error) {
      console.log("Err: ", error);
    }
  }
};
